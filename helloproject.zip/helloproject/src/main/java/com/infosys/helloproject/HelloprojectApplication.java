package com.infosys.helloproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloprojectApplication.class, args);
	}

}
